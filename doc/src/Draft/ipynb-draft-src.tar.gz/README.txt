This IPython notebook draft.ipynb does not require any additional
programs.
